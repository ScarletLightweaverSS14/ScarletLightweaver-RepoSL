# Nullstar — stage 2: basic combat and audio

Nullstar is a separate weapon from the Hadal Blade. Static sprites and basic melee/audio are now implemented. The boss abilities, passive animation, cinematic effects and arena remain the later stages listed in **CONCEPT.md**.

Restart with the updated resources and spawn:

```text
self spawn:in "belt" ScarletNullstar
```

Move it into your hand and use the normal wield control (Z by default). Both hands are required for melee. The weapon deals **32 slash + 8 piercing** before resistances, with **1.33 seconds between attacks**, **1.65-tile edge reach** and a **70-degree wide attack**. Single-target and wide attacks use the same base damage. There is no added armor bypass, stun or lingering hazard. These are a starting balance for the later encounter, not a finished boss balance.

Click attacks use the existing blade thrust animation; wide attacks alternate sweeping directions. `wideAnimationRotation: 180` correctly faces the upright sword outward, and `animationOffset: 0.8` keeps its visual reach close to the hit range. The blade remains a physical weapon without activation or energy-sword sounds.

## Basic audio

Open **audio-preview.html** to audition all seven clips offline, including random swings and an example landed strike. The clips combine pitch-shifted sword/stone recordings with filtered or reversed crystal accents and a short synthesized resonance. There are two swing variants, two impact variants, a glance fallback, and separate wield/unwield sounds. Playback has restrained pitch variation; there is no idle hum.

All clips are mono, 44.1 kHz, 16-bit PCM WAV, between 0.45 and 0.72 seconds long. Robust supports WAV directly, and pre-mixing the layers keeps each cue to one audio source. Audio lives in `Resources/Audio/_Starlight/Weapons/Nullstar/`, with CC-BY-SA-3.0 source attribution in `attributions.yml`. The recipes are in `Build-Audio.ps1`, which reuses the game's VorbisPizza decoder from the local client build.

Existing target material sounds retain their normal precedence over weapon impact sounds. The glance cue is configured through `soundNoDamage`; the current shared sound system can choose a target's sound or the weapon's hit cue first. This stage does not change audio behavior for other weapons.

## Deliverables

- Loaded prototype: `Resources/Prototypes/_Starlight/Admeme/scarlet/nullstar.yml`.
- `Resources/Textures/_Starlight/Admeme/Scarlet/Nullstar.rsi`: static 32 x 64 item icon, with the weapon approximately 50 pixels tall.
- `NullstarInhands.rsi`: 64 x 64 frames for both hands, normal/wielded aliases, South/North/East/West directions.
- `NullstarBelt.rsi`: 32 x 32 belt overlays in all four directions.
- **contact-sheet.png**: exported native sprites and an equal-zoom Hadal comparison.
- **CONCEPT.md**: the complete encounter direction, all eight ability concepts, staged implementation order, extraction/arena constraints, confirmed repository entry points and a draft server-wide release announcement.
- **audio-preview.html**: standalone audition page with waveforms and game-volume trims.
- **nullstar-stage2.zip**: current portable package with repository-relative paths. The earlier stage-1 ZIP is retained as a snapshot.

## Art and reproducibility

Built-in OpenAI image generation produced the sword artwork. `source/nullstar-native.png` is the final export source; the earlier source images retain the concept iterations. The exact initial, proportion-revision and native-sprite prompts are saved in the three `*prompt.txt` files here.

The exporter performs native-resolution sampling, palette conversion, directional placement and RSI packing. It uses coverage sampling to avoid losing thin edges during reduction, then writes at most 16 opaque colors with binary alpha and transparent margins. No existing cosmic-cult weapon pixels were copied. The new art uses the repository's default CC-BY-SA-3.0 non-code license, recorded with provenance in each RSI metadata file.

```powershell
./output/nullstar/Export-Sprites.ps1
./output/nullstar/Validate-Sprites.ps1
./output/nullstar/Build-Preview.ps1
./output/nullstar/Build-Audio.ps1
./output/nullstar/Validate-Audio.ps1
./output/nullstar/Build-AudioPreview.ps1
./output/nullstar/Package.ps1
```

## Validation

The RSI/schema/image checks from stage 1 cover 3 folders, 6 states and 21 packed frames; results are in `validation.txt`. Stage 2 leaves those sprites unchanged. `audio-validation.txt` covers WAV headers, mono format, durations, peak/RMS levels, DC offset and faded endpoints. `combat-check.log` records the existing prototype-component and engine audio-loading checks. No game C# changes or new test systems were needed. Live attack alignment and subjective audio balance still need an in-game check; file-level audio validation is not a listening test.

Next stage: Nullstar Unbound as an isolated release effect. The 90-second seal interaction, survival changes, arena clearing/atmosphere rebuild and lighting-preserving Theta-style announcement remain later integration work.
