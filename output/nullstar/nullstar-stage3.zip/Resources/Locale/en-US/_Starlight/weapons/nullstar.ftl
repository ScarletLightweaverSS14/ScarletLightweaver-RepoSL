nullstar-must-wield = Grip Nullstar with both hands to release it.
