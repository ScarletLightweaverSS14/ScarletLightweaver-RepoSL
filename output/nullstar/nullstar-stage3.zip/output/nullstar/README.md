# Nullstar — stage 3: Nullstar Unbound

Nullstar is a separate weapon from the Hadal Blade. Static sprites, basic melee/audio and the standalone Unbound release are implemented. The remaining abilities, passive blade animation and encounter setup follow the stages in **CONCEPT.md**.

Restart with the updated resources and spawn:

```text
self spawn:in "belt" ScarletNullstar
```

Move it into your hand and use the normal wield control (Z by default). Both hands are required for melee. The weapon deals **32 slash + 8 piercing** before resistances, with **1.33 seconds between attacks**, **1.65-tile edge reach** and a **70-degree wide attack**. Single-target and wide attacks use the same base damage. There is no added armor bypass, stun or lingering hazard. These are a starting balance for the later encounter, not a finished boss balance.

Click attacks use the existing blade thrust animation; wide attacks alternate sweeping directions. `wideAnimationRotation: 180` correctly faces the upright sword outward, and `animationOffset: 0.8` keeps its visual reach close to the hit range. The blade remains a physical weapon without activation or energy-sword sounds.

## Nullstar Unbound preview

After rebuilding the client and server, spawn the separate preview variant:

```text
self spawn:in "belt" ScarletNullstarUnboundPreview
```

Hold it in both hands and activate **Nullstar Unbound**. The preview uses a visible one-second DoAfter that cancels on movement, damage or hand changes. Each blade releases once; dropping or passing it does not reset it. Spawn a fresh preview sword to repeat.

The expanding ring reaches **7 tiles in 0.65 seconds**, applying one outward throw per unobstructed mob, configured for approximately **4 tiles** of displacement on normal ground. Walls block the knockback. The wielder, contained mobs, ghosts, anchored entities and buckled mobs are excluded. No direct damage or stun is applied, but ordinary environmental and collision consequences still apply. Crystal debris is decorative; loose items are not launched. The decorative ring itself may be visible through walls.

Four original 128x128 effect layers show an expanding pressure ring, scattering amethyst debris, a brief core flare, and a rift that narrows and fades. One effect entity lasts three seconds. Networked start time aligns the client animation with server wave expansion; entering visibility late does not restart the effect. An 8.5-second mono cue layers a heavy explosion body, distant blast rumble, stone fracture, restrained crystal accents and descending pressure with slight pitch variation. The sound plays at the release position independently of the three-second visual entity, allowing its full tail to finish.

Open **unbound-preview.html** for a standalone animation/audio preview with a scrubber. This is an offline illustration using the shipped assets and timing, not a gameplay recording.

The ordinary `ScarletNullstar` grants no preview action. Its server-side `NullstarUnboundSystem.TryRelease` entry point is ready for later extraction completion after equipping/wielding the blade. This stage does not create a stone, arena, Scarlet transformation, boss bar, survival immunity, announcement or alert change.

Compare the revised and previous release in **unbound-audio-comparison.html**. **audio-search.md** lists verified CC0 alternatives and search phrases.

## Basic audio

Open **audio-preview.html** to audition all eight clips offline, including random swings and an example landed strike. The clips combine pitch-shifted sword/stone recordings with filtered or reversed crystal accents and a short synthesized resonance. There are two swing variants, two impact variants, a glance fallback, and separate wield/unwield sounds. Playback has restrained pitch variation; there is no idle hum.

All clips are mono, 44.1 kHz, 16-bit PCM WAV. Basic combat clips are 0.45–0.72 seconds; Unbound is 8.5 seconds. Robust supports WAV directly, and pre-mixing the layers keeps each cue to one audio source. Audio lives in `Resources/Audio/_Starlight/Weapons/Nullstar/`, with CC-BY-SA-3.0 source attribution in `attributions.yml`. The recipes are in `Build-Audio.ps1`, which reuses the game's VorbisPizza decoder from the local client build.

Existing target material sounds retain their normal precedence over weapon impact sounds. The glance cue is configured through `soundNoDamage`; the current shared sound system can choose a target's sound or the weapon's hit cue first. This stage does not change audio behavior for other weapons.

## Deliverables

- Loaded prototype: `Resources/Prototypes/_Starlight/Admeme/scarlet/nullstar.yml`.
- `Resources/Textures/_Starlight/Admeme/Scarlet/Nullstar.rsi`: static 32 x 64 item icon, with the weapon approximately 50 pixels tall.
- `NullstarInhands.rsi`: 64 x 64 frames for both hands, normal/wielded aliases, South/North/East/West directions.
- `NullstarBelt.rsi`: 32 x 32 belt overlays in all four directions.
- **contact-sheet.png**: exported native sprites and an equal-zoom Hadal comparison.
- **CONCEPT.md**: the complete encounter direction, all eight ability concepts, staged implementation order, extraction/arena constraints, confirmed repository entry points and a draft server-wide release announcement.
- **audio-preview.html**: standalone audition page with waveforms and game-volume trims.
- **nullstar-stage3.zip**: current portable package with repository-relative paths. The earlier stage ZIPs are retained as snapshots.

## Art and reproducibility

Built-in OpenAI image generation produced the sword artwork. `source/nullstar-native.png` is the final export source; the earlier source images retain the concept iterations. The exact initial, proportion-revision and native-sprite prompts are saved in the three `*prompt.txt` files here.

The exporter performs native-resolution sampling, palette conversion, directional placement and RSI packing. It uses coverage sampling to avoid losing thin edges during reduction, then writes at most 16 opaque colors with binary alpha and transparent margins. No existing cosmic-cult weapon pixels were copied. The new art uses the repository's default CC-BY-SA-3.0 non-code license, recorded with provenance in each RSI metadata file.

```powershell
./output/nullstar/Export-Sprites.ps1
./output/nullstar/Export-Unbound.ps1
./output/nullstar/Validate-Sprites.ps1
./output/nullstar/Build-Preview.ps1
./output/nullstar/Build-Audio.ps1
./output/nullstar/Validate-Audio.ps1
./output/nullstar/Build-AudioPreview.ps1
./output/nullstar/Build-UnboundPreview.ps1
./output/nullstar/Build-UnboundComparison.ps1
./output/nullstar/Package.ps1
```

## Validation

`validation.txt` covers four RSI folders, ten states and 25 packed frames. `audio-validation.txt` covers all eight WAVs: headers, mono format, duration, peak/RMS levels, DC offset and faded endpoints. Build and engine integration results are recorded separately in `unbound-verification.txt`.

`NullstarUnboundTest.cs` is an archived temporary check, outside the test project. It checks the preview/normal separation, wield requirement, outward impulse, wall obstruction, range, no direct damage, caster exclusion and one-use persistence. No runtime test systems were added.

Live visual alignment, spatial audio balance, preview DoAfter interruption and behavior on real map geometry still need an in-game check.

Next stage: **Rift Cleave**. The 90-second seal interaction, survival changes, arena clearing/atmosphere rebuild and lighting-preserving Theta-style announcement remain later integration work.


