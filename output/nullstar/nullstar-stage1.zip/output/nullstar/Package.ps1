param([string] $RepoRoot = (Resolve-Path "$PSScriptRoot/../..").Path)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression
$files=[Collections.Generic.List[string]]::new()
foreach($folder in @('Nullstar.rsi','NullstarInhands.rsi','NullstarBelt.rsi')){
    Get-ChildItem -LiteralPath "$RepoRoot/Resources/Textures/_Starlight/Admeme/Scarlet/$folder" -File | ForEach-Object {$files.Add($_.FullName)}
}
$files.Add((Join-Path $RepoRoot 'Resources/Prototypes/_Starlight/Admeme/scarlet/nullstar.yml'))
Get-ChildItem -LiteralPath $PSScriptRoot -File | Where-Object {$_.Extension -in '.md','.png','.ps1','.txt'} | ForEach-Object {$files.Add($_.FullName)}
Get-ChildItem -LiteralPath "$PSScriptRoot/source" -File | ForEach-Object {$files.Add($_.FullName)}
$stream=[IO.File]::Open("$PSScriptRoot/nullstar-stage1.zip",[IO.FileMode]::Create)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($file in $files){
        $relative=[IO.Path]::GetRelativePath($RepoRoot,$file).Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file,$relative,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
}finally{$archive.Dispose();$stream.Dispose()}
Write-Output "Packaged $($files.Count) files into nullstar-stage1.zip"
