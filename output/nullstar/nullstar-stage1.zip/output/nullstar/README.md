# Nullstar — stage 1: sword sprites and concept package

Nullstar is a separate weapon from the Hadal Blade. This stage supplies static game sprites and a spawnable visual-review item. Basic combat/audio tuning, abilities, animation and the arena remain the later stages listed in **CONCEPT.md**.

Restart with the updated resources and spawn:

```text
self spawn:in "belt" ScarletNullstar
```

Move it into your hand and use the normal wield control (Z by default) to inspect the two-handed pose. The item uses provisional 20 slash damage and a 1.25-second swing interval. It does not create an arena or transform its holder.

## Deliverables

- Loaded prototype: `Resources/Prototypes/_Starlight/Admeme/scarlet/nullstar.yml`.
- `Resources/Textures/_Starlight/Admeme/Scarlet/Nullstar.rsi`: static 32 x 64 item icon, with the weapon approximately 50 pixels tall.
- `NullstarInhands.rsi`: 64 x 64 frames for both hands, normal/wielded aliases, South/North/East/West directions.
- `NullstarBelt.rsi`: 32 x 32 belt overlays in all four directions.
- **contact-sheet.png**: exported native sprites and an equal-zoom Hadal comparison.
- **CONCEPT.md**: the complete encounter direction, all eight ability concepts, staged implementation order, extraction/arena constraints, confirmed repository entry points and a draft server-wide release announcement.
- **nullstar-stage1.zip**: portable package with repository-relative paths.

## Art and reproducibility

Built-in OpenAI image generation produced the sword artwork. `source/nullstar-native.png` is the final export source; the earlier source images retain the concept iterations. The exact initial, proportion-revision and native-sprite prompts are saved in the three `*prompt.txt` files here.

The exporter performs native-resolution sampling, palette conversion, directional placement and RSI packing. It uses coverage sampling to avoid losing thin edges during reduction, then writes at most 16 opaque colors with binary alpha and transparent margins. No existing cosmic-cult weapon pixels were copied. The new art uses the repository's default CC-BY-SA-3.0 non-code license, recorded with provenance in each RSI metadata file.

```powershell
./output/nullstar/Export-Sprites.ps1
./output/nullstar/Validate-Sprites.ps1
./output/nullstar/Build-Preview.ps1
./output/nullstar/Package.ps1
```

## Validation

The RSI/schema/image checks cover 3 folders, 6 states and 21 packed frames; results are in `validation.txt`. The existing engine prototype-component check is recorded in `prototype-check.log`. The native contact sheet was visually reviewed. No C# changes or new test systems were needed for this stage. In-game character occlusion, belt positioning and wield alignment still need a live client check.

Next stage: basic melee feel, attack presentation and audio. Boss effects, the 90-second seal interaction, survival changes, arena clearing/atmosphere rebuild and the lighting-preserving Theta-style announcement are design work only at this point.
